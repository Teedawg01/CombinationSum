//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        CombinationSum combination = new CombinationSum();


        int[] candidates1 = {2, 3, 6, 7};
        int target1 = 7;
        System.out.println("Test Case 1: " + combination.combinationSum(candidates1, target1));

        int[] candidates2 = {2, 3, 5};
        int target2 = 8;
        System.out.println("Test Case 2: " + combination.combinationSum(candidates2, target2));

        int[] candidates3 = {2};
        int target3 = 1;
        System.out.println("Test Case 3: " + combination.combinationSum(candidates3, target3));

    }
}